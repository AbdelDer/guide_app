class Restaurant {
  String imageUrl;
  String name;
  String address;
  int price;

  Restaurant({
    this.imageUrl,
    this.name,
    this.address,
    this.price,
  });
}

final List<Restaurant> restaurants = [
  Restaurant(
    imageUrl: 'assets/images/restaurant0.jpg',
    name: 'Restaurant 0',
    address: '404 Great St',
    price: 175,
  ),
  Restaurant(
    imageUrl: 'assets/images/restaurant1.jpg',
    name: 'Restaurant 1',
    address: '404 Great St',
    price: 300,
  ),
  Restaurant(
    imageUrl: 'assets/images/restaurant2.jpg',
    name: 'Restaurant 2',
    address: '404 Great St',
    price: 240,
  ),
];
