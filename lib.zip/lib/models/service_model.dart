class Service {
  String imageUrl;
  String name;
  String address;
  int price;

  Service({
    this.imageUrl,
    this.name,
    this.address,
    this.price,
  });
}

final List<Service> services = [
  Service(
    imageUrl: 'assets/images/restaurant0.jpg',
    name: 'Service 0',
    address: '404 Great St',
    price: 175,
  ),
  Service(
    imageUrl: 'assets/images/restaurant1.jpg',
    name: 'Service 1',
    address: '404 Great St',
    price: 300,
  ),
  Service(
    imageUrl: 'assets/images/restaurant2.jpg',
    name: 'Service 2',
    address: '404 Great St',
    price: 240,
  ),
];
