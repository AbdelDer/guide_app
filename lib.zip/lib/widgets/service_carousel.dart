import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:guide_app/database/database_helper.dart';
import 'package:guide_app/models/partner_model.dart';
import 'package:guide_app/models/service_model.dart';
import 'package:guide_app/screens/detail_screen.dart';

class ServiceCarousel extends StatefulWidget {
  @override
  _ServiceCarouselState createState() => _ServiceCarouselState();
}

class _ServiceCarouselState extends State<ServiceCarousel> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
//        Padding(
//          padding: EdgeInsets.symmetric(horizontal: 20.0),
//          child: Row(
//            mainAxisAlignment: MainAxisAlignment.spaceBetween,
//            children: <Widget>[
//              Text(
//                'Hôtels Exclusifs',
//                style: TextStyle(
//                  fontSize: 22.0,
//                  fontWeight: FontWeight.bold,
//                  letterSpacing: 1.5,
//                ),
//              ),
////              GestureDetector(
////                onTap: () => print('Voir tout'),
////                child: Text(
////                  'Voir tout',
////                  style: TextStyle(
////                    color: Theme.of(context).primaryColor,
////                    fontSize: 16.0,
////                    fontWeight: FontWeight.w600,
////                    letterSpacing: 1.0,
////                  ),
////                ),
////              ),
//            ],
//          ),
//        ),
        SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height - 200,
            child: ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: services.length,
              itemBuilder: (BuildContext context, int index) {
                Service service = services[index];
                return GestureDetector(
                  onTap: () async{
//                    DatabaseHelper dh = DatabaseHelper();
//                    await dh.drop();
                  },
                  child: Container(
                    margin: EdgeInsets.all(10.0),
                    width: MediaQuery.of(context).size.width,
                    height: 300,
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: <Widget>[
                        Positioned(
                          width: MediaQuery.of(context).size.width,
                          bottom: 15.0,
                          child: Container(
                            height: 120.0,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Text(
                                    service.name,
                                    style: TextStyle(
                                      fontSize: 22.0,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 1.2,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height: 2.0),
                                  Text(
                                    service.address,
                                    style: TextStyle(
                                      color: Colors.grey,
                                    ),
                                  ),
//                              SizedBox(height: 2.0),
//                              Text(
//                                '\$${service.price} / nuit',
//                                style: TextStyle(
//                                  fontSize: 18.0,
//                                  fontWeight: FontWeight.w600,
//                                ),
//                              ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                offset: Offset(0.0, 2.0),
                                blurRadius: 6.0,
                              ),
                            ],
                          ),
                          child: ClipRRect(
//                            borderRadius: BorderRadius.circular(20.0),
                            child: Image(
                              height: 180.0,
                              width: MediaQuery.of(context).size.width,
                              image: AssetImage(service.imageUrl),
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
