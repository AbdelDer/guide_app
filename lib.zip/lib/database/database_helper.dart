import 'dart:async';
import 'dart:io';
import 'package:guide_app/models/partner_model.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static Database _db;

  Future<Database> get db async {
    if (_db != null) {
      return _db;
    } else {
      _db = await initDb();
      return _db;
    }
  }

  initDb() async {
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, "guide.db");
    print("path is $path");
    var db = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
      await db.execute('''
      CREATE TABLE IF NOT EXISTS "partner" (id integer primary key autoincrement, name TEXT, image TEXT, location	TEXT, type TEXT)''');
      await db.execute('''INSERT INTO partner(Name, image, Location, type)
VALUES
(
"Torgan Hammam", "1.jpeg", "Tétouan تطوان", "Spa-hammam حمام-منتجع صحي"
),
(
"Norte de Africa", "2.jpeg", "Ceuta سبتة", "Agence وكالة وكالات"
),
(
"L'escapade", "3.jpeg", "Marrakech مراكش", "Cafes مقاهي مقهى"
),
(
"L'escapade", "3.jpeg", "Marrakech مراكش", "Restaurants مطعم مطاعم"
),
(
"Tamouda Shop", "4.jpeg", "M'diq مضيق", "Coiffure حلاقة"
),
(
"Tamouda Shop", "4.jpeg", "M'diq مضيق", "Coiffure حلاقة"
),
(
"Senator Hotel", "5.jpeg", "Fnideq, Tétouan تطوان الفنيدق", "Hotels فندق فنادق"
),
(
"Syrene Bateau Restaurant Promenade en mer ", "6.jpeg", "Port marina smir, marina beach ميناء مارينا سمير", "Loisirs هوايات هواية"
),
(
"Syrene Bateau Restaurant Promenade en mer ", "6.jpeg", "Port marina smir, marina beach ميناء مارينا سمير", "Restaurants مطعم مطاعم"
),
(
"PARAPHARMACIE Bab Sebta", "7.jpeg", "Fnideq الفنيدق", "Parapharmacie صيدلية"
),
(
"Joyeria MARAM", "8.jpeg", "Fnideq الفنيدق", "Bijouterie متجر مجوهرات"
),
(
"Institut Prive Amjad Al Andalous", "9.jpeg", "Fnideq الفنيدق", "Ecoles مدرسة مدارس"
),
(
"Auto/Moto Janane Khalid", "10.jpeg", "Rsd. Al Amira, Bv. Lyle, Imm Assil étg 1 N 1", "Ecoles مدرسة مدارس"
),
(
"Mary Joya", "11.jpeg", "Fnideq الفنيدق", "Spa-hammam حمام-منتجع صحي"
),
(
"Panaderia Pasteleria Zahrae", "12.jpeg", "Fnideq الفنيدق", "Patisserie - boulangerie مخبزة - حلويات"
),
(
"La Ferma", "13.jpeg", "M'diq مضيق", "Hotels فنادق فندق"
),
(
"La Ferma", "13.jpeg", "M'diq مضيق", "Restaurants مطعم مطاعم"
),
(
"La Ferma", "13.jpeg", "M'diq مضيق", "Loisirs هوايات هواية"
),
(
"Chams", "14.jpeg", "Tétouan تطوان", "Hotels فنادق فندق"
),
(
"Espace Dar Argana", "15.jpeg", "M'diq مضيق", "Hotels فنادق فندق"
);''');
    });

    return db;
  }

  Future<Partner> insert(Partner p) async {
    var dbClient = await db;
    p.id = await dbClient.insert("partner", p.toMap());
    return p;
  }

  drop() async {
    var dbClient = await db;
    dbClient.close();
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentDirectory.path, "guide.db");
    await deleteDatabase(path);
  }
}
